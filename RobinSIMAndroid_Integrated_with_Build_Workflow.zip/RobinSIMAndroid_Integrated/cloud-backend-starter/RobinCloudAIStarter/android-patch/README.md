# Android-side changes for cloud forwarding mode

For the forwarded-call architecture, the live call audio does **not** pass through the Android app. Do not add `AudioRecord`, `MediaRecorder`, or Android TextToSpeech expecting them to hear/inject ordinary cellular call audio; Android does not expose a reliable general-purpose API for that.

Recommended UI-only patch:
- Add a “Cloud call assistant” mode toggle in `MainActivity`.
- When enabled, display the forwarding destination and a checklist; do not claim it is enabled until the user has separately configured carrier forwarding and the cloud provider.
- Turn off the prototype's local `auto_answer` preference when switching into cloud-forwarding mode.
- Offer a button that opens the app's own settings or a browser to the operator/provider dashboard; do not put API credentials in the app.
- Keep a manual disable-forwarding instruction visible. Carrier forwarding codes vary; use the carrier's official instructions rather than hardcoding a universal code.

A minimal safe preference change when the user selects cloud mode:

```kotlin
// Inside the click listener for a "Use Cloud Call Assistant" toggle:
prefs.edit()
    .putBoolean("cloud_forwarding_mode", true)
    .putBoolean("auto_answer", false)
    .apply()
```

Then update `RobinInCallService.onCallAdded` before the auto-answer branch:

```kotlin
val prefs = getSharedPreferences("robin_settings", MODE_PRIVATE)
if (prefs.getBoolean("cloud_forwarding_mode", false)) {
    // Calls are expected to be forwarded by the carrier.
    // Do not auto-answer locally in this mode.
    return
}
if (!prefs.getBoolean("auto_answer", false)) return
```

This only prevents local auto-answer conflicts; it does not configure carrier call forwarding or connect the Android app to call audio. Build and test the Android project separately.
