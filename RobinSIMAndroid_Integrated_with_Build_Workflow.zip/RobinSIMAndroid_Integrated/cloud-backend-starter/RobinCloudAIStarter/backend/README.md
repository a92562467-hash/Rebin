# Robin Cloud AI — bidirectional call-audio starter

This backend is a **starter integration**, not a tested production call centre. It bridges a Twilio bidirectional Media Stream and an OpenAI Realtime speech model. It is not a way for an ordinary Android app to inject AI audio into a direct SIM call.

## How the real call path works

1. The caller calls your existing mobile number.
2. Your carrier forwards the call to a telephony number configured with Twilio (or another provider with bidirectional media streaming).
3. Twilio requests `POST /voice`.
4. Twilio streams the call audio to `wss://YOUR_DOMAIN/media`.
5. This server forwards caller audio to OpenAI Realtime and sends generated G.711 μ-law audio back into the call.

The Android app is not the audio bridge. In call-forwarding mode, the mobile carrier forwards the call before the Android `InCallService` can provide the media. The app can still provide settings/status, but it cannot make this cloud route work by itself.

## Credentials and services required

- **OpenAI API key** with access/billing enabled for a compatible Realtime model. Keep it only on the backend.
- **Twilio account**, a voice-capable Twilio number, and its Account Auth Token. Configure the number's Voice webhook to `https://YOUR_DOMAIN/voice` using HTTP POST.
- **Public HTTPS/WSS hosting** for this Node server. A private `localhost` URL will not receive provider webhooks.
- **Carrier call forwarding** from the mobile SIM number to the Twilio number. Carrier availability, charges, and forwarding settings vary by operator.
- Optional domain and TLS hosting. Production should use a stable HTTPS domain and validate both HTTP webhook and WebSocket upgrade signatures according to Twilio's current security docs.

Never paste keys into this chat, an APK, Kotlin source, Git repository, or frontend JavaScript. Use environment variables/secrets in your hosting dashboard.

## Setup

1. Install Node.js 20 or newer on a server.
2. Copy `.env.example` to `.env` and set `OPENAI_API_KEY`, `TWILIO_AUTH_TOKEN`, `PUBLIC_BASE_URL`, and model settings.
3. Run `npm install`, then `npm start`.
4. Deploy behind HTTPS/WSS and make sure the public URL routes to this server.
5. Set your Twilio number's Voice webhook to `POST https://YOUR_DOMAIN/voice`.
6. Configure call forwarding with your carrier only after testing the Twilio number directly.
7. Test using a non-sensitive test call first. Tell callers clearly that an AI is answering and avoid recording or retaining audio unless appropriate consent and legal requirements are handled.

## Important production gaps

- Verify Twilio's WebSocket upgrade signature before accepting `/media` connections. The sample has a clear TODO at the upgrade handler; do not expose this as production-ready until it is implemented.
- Add authentication/rate limiting for any admin endpoints (none are included here), request limits, abuse protection, monitoring, call duration limits, and cost controls.
- Handle OpenAI reconnects, provider disconnects, duplicate webhooks, call transfer, DTMF, queue/backpressure, and graceful finalization.
- Confirm the exact Realtime model name and event schema enabled for your OpenAI project; API models and event formats can change.
- The code logs errors but intentionally does not persist caller audio or transcripts.
- The sample greeting is in Hindi; update it to match your desired disclosure and language.

## Android project relationship

Your uploaded source has `MainActivity.kt` and `RobinInCallService.kt` for the Android default-dialer/auto-answer prototype. Keep local SIM auto-answer OFF when using call forwarding to avoid confusing behavior. Call forwarding and the cloud stream are configured at the carrier/provider/backend level, not by `RobinInCallService`.

This starter has not been built, deployed, or tested against a live phone call in this environment.


## 200 Hindi seed utterances

`knowledge-phrases-hi.json` contains 200 example sentences plus whitespace-split phrase units. The model receives these as conversational examples and safety guidance. It is **not** a dictionary or verified knowledge base, and it should not be asked to stitch random words into an answer. The model must interpret each caller's meaning and generate a grounded response. Phrase concatenation alone cannot guarantee accurate answers.

For large call volumes, each call uses its own Realtime session. You must load-test provider concurrency, rate limits, token/audio costs, and server CPU/network capacity before claiming support for hundreds or thousands of simultaneous calls.


## Abhishek fallback phrase

The prompt is configured to say:
> "Abhishek sir abhi nahi hain, kripya thodi der baad call karein. Please."

It should use this when the caller asks for Abhishek and no verified availability/transfer feature exists, or after two attempts to clarify an unclear request, or when it still cannot provide a reliable answer. This is a **default scripted response**, not a real-time check that Abhishek is unavailable. For true availability, connect a verified calendar/presence tool; for call transfer, configure a telephony transfer destination. Neither is implemented in this starter.

The model may not always follow a prompt perfectly. If this phrase must be guaranteed, implement server-side call-state/intent handling or a deterministic fallback tool, and test it with real calls.
