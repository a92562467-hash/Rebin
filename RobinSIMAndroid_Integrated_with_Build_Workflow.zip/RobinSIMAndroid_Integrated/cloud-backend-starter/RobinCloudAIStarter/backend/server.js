require("dotenv").config();

const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const twilio = require("twilio");
const { makeInstructions } = require("./robin-prompts");

const app = express();
const server = http.createServer(app);
const mediaWss = new WebSocket.Server({ noServer: true });

const PORT = Number(process.env.PORT || 8080);
const PUBLIC_BASE_URL = (process.env.PUBLIC_BASE_URL || "").replace(/\/+$/, "");
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_REALTIME_MODEL || "gpt-realtime";
const VALIDATE_SIGNATURE = (process.env.VALIDATE_TWILIO_SIGNATURE || "true").toLowerCase() === "true";

if (!OPENAI_API_KEY) {
  console.error("Missing OPENAI_API_KEY. Copy .env.example to .env and configure it.");
  process.exit(1);
}
if (!PUBLIC_BASE_URL.startsWith("https://")) {
  console.error("PUBLIC_BASE_URL must be your public HTTPS URL (for example, a deployed domain).");
  process.exit(1);
}

app.set("trust proxy", true);
app.use(express.urlencoded({ extended: false }));
app.use(express.json({ limit: "64kb" }));

function requestIsFromTwilio(req) {
  if (!VALIDATE_SIGNATURE) return true; // Local development only; do not disable in production.
  const signature = req.header("X-Twilio-Signature") || "";
  const url = `${PUBLIC_BASE_URL}${req.originalUrl}`;
  return twilio.validateRequest(process.env.TWILIO_AUTH_TOKEN || "", signature, url, req.body || {});
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "robin-cloud-call-ai" });
});

/**
 * Configure your Twilio number's Voice webhook to:
 *   POST https://YOUR_DOMAIN/voice
 *
 * Calls are streamed bidirectionally to this server. The server bridges
 * 8 kHz G.711 μ-law audio to/from OpenAI Realtime.
 */
app.post("/voice", (req, res) => {
  if (!process.env.TWILIO_AUTH_TOKEN) {
    return res.status(500).send("Server is missing TWILIO_AUTH_TOKEN.");
  }
  if (!requestIsFromTwilio(req)) {
    return res.status(403).send("Invalid Twilio signature.");
  }

  const streamUrl = PUBLIC_BASE_URL.replace(/^https:/, "wss:") + "/media";
  const twiml = new twilio.twiml.VoiceResponse();
  twiml.say({ language: "hi-IN" }, "Namaste. Main Robin ka AI assistant hoon. Aapki baat AI ke saath process hogi.");
  const connect = twiml.connect();
  connect.stream({ url: streamUrl });
  res.type("text/xml").send(twiml.toString());
});

server.on("upgrade", (req, socket, head) => {
  const pathname = new URL(req.url, "http://localhost").pathname;
  if (pathname !== "/media") {
    socket.destroy();
    return;
  }
  // Production hardening note: validate Twilio's WebSocket upgrade signature
  // using the current Twilio Media Streams security guidance before deployment.
  mediaWss.handleUpgrade(req, socket, head, (ws) => {
    mediaWss.emit("connection", ws, req);
  });
});

mediaWss.on("connection", (twilioWs) => {
  let streamSid = null;
  let openaiWs = null;
  let closed = false;

  const sendTwilio = (message) => {
    if (twilioWs.readyState === WebSocket.OPEN) {
      twilioWs.send(JSON.stringify(message));
    }
  };

  const cleanup = () => {
    if (closed) return;
    closed = true;
    try {
      if (openaiWs && openaiWs.readyState === WebSocket.OPEN) {
        openaiWs.send(JSON.stringify({ type: "session.close" }));
        openaiWs.close();
      }
    } catch (_) {}
    try { twilioWs.close(); } catch (_) {}
  };

  twilioWs.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch (_) { return; }

    if (msg.event === "start") {
      streamSid = msg.start && msg.start.streamSid;
      openaiWs = new WebSocket(
        `wss://api.openai.com/v1/realtime?model=${encodeURIComponent(MODEL)}`,
        {
          headers: {
            Authorization: `Bearer ${OPENAI_API_KEY}`,
            "OpenAI-Beta": "realtime=v1"
          }
        }
      );

      openaiWs.on("open", () => {
        openaiWs.send(JSON.stringify({
          type: "session.update",
          session: {
            modalities: ["text", "audio"],
            instructions: makeInstructions(),
            voice: "marin",
            input_audio_format: "g711_ulaw",
            output_audio_format: "g711_ulaw",
            input_audio_transcription: { model: "gpt-4o-mini-transcribe" },
            turn_detection: {
              type: "server_vad",
              threshold: 0.5,
              prefix_padding_ms: 300,
              silence_duration_ms: 550
            }
          }
        }));
        // Prompt the assistant to introduce itself after the audio stream is ready.
        openaiWs.send(JSON.stringify({ type: "response.create", response: { modalities: ["audio", "text"] } }));
      });

      openaiWs.on("message", (data) => {
        let event;
        try { event = JSON.parse(data.toString()); } catch (_) { return; }

        if (event.type === "response.output_audio.delta" && event.delta && streamSid) {
          sendTwilio({
            event: "media",
            streamSid,
            media: { payload: event.delta }
          });
        } else if (event.type === "input_audio_buffer.speech_started") {
          // Clear queued playback so the caller can interrupt the AI naturally.
          if (streamSid) sendTwilio({ event: "clear", streamSid });
          try { openaiWs.send(JSON.stringify({ type: "response.cancel" })); } catch (_) {}
        } else if (event.type === "error") {
          console.error("OpenAI Realtime error:", event.error || event);
        }
      });

      openaiWs.on("error", (err) => {
        console.error("OpenAI WebSocket error:", err.message);
        cleanup();
      });
      openaiWs.on("close", () => {
        if (!closed) console.log("OpenAI voice session closed");
      });
      return;
    }

    if (msg.event === "media" && openaiWs && openaiWs.readyState === WebSocket.OPEN) {
      openaiWs.send(JSON.stringify({
        type: "input_audio_buffer.append",
        audio: msg.media.payload
      }));
    } else if (msg.event === "stop") {
      cleanup();
    }
  });

  twilioWs.on("close", cleanup);
  twilioWs.on("error", (err) => {
    console.error("Twilio Media WebSocket error:", err.message);
    cleanup();
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Robin Cloud AI listening on port ${PORT}`);
});
