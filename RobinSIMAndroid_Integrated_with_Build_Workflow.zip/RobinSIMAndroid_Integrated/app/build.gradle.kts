plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.robin.simassistant"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.robin.simassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
