package com.robin.simassistant

import android.app.role.RoleManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.telecom.Call
import android.telecom.InCallService
import android.telecom.VideoProfile
import android.util.Log

/**
 * Native Telecom integration prototype.
 * Auto-answer only runs when the user enabled it and this app is the default dialer.
 * This does not expose the remote cellular call audio to the AI.
 */
class RobinInCallService : InCallService() {
    private val handler = Handler(Looper.getMainLooper())
    private val callbacks = mutableMapOf<Call, Call.Callback>()

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        Log.i(TAG, "onCallAdded state=${call.state}")
        val prefs = getSharedPreferences("robin_settings", MODE_PRIVATE)
        val isDialer = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q &&
            getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_DIALER)
        if (!prefs.getBoolean("auto_answer", false) || !isDialer) {
            Log.i(TAG, "Auto-answer skipped: disabled or not default dialer")
            return
        }

        val callback = object : Call.Callback() {
            override fun onStateChanged(changedCall: Call, state: Int) {
                Log.i(TAG, "Call state changed=$state")
                if (state == Call.STATE_RINGING) scheduleAnswer(changedCall)
                if (state != Call.STATE_RINGING) handler.removeCallbacksAndMessages(changedCall)
            }
        }
        callbacks[call] = callback
        call.registerCallback(callback, handler)
        if (call.state == Call.STATE_RINGING) scheduleAnswer(call)
    }

    private fun scheduleAnswer(call: Call) {
        // Short delay; set to zero if you intentionally want immediate answer.
        handler.postAtTime({
            try {
                val prefs = getSharedPreferences("robin_settings", MODE_PRIVATE)
                val isDialer = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q &&
                    getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_DIALER)
                if (prefs.getBoolean("auto_answer", false) && isDialer && call.state == Call.STATE_RINGING) {
                    call.answer(VideoProfile.STATE_AUDIO_ONLY)
                    Log.i(TAG, "Answer requested")
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "Answer not permitted", e)
            } catch (e: Exception) {
                Log.e(TAG, "Could not answer call", e)
            }
        }, call, SystemClock.uptimeMillis() + 700L)
    }

    override fun onCallRemoved(call: Call) {
        handler.removeCallbacksAndMessages(call)
        callbacks.remove(call)?.let { callback ->
            try { call.unregisterCallback(callback) } catch (_: Exception) {}
        }
        super.onCallRemoved(call)
        Log.i(TAG, "onCallRemoved")
    }

    companion object { private const val TAG = "RobinSIM" }
}
