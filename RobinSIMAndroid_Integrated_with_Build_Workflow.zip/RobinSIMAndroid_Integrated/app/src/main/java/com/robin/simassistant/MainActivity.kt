package com.robin.simassistant

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var detail: TextView
    private val prefs by lazy { getSharedPreferences("robin_settings", Context.MODE_PRIVATE) }
    private val permissionRequestCode = 710

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestRuntimePermissions()
        updateStatus()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(0xFF0B1220.toInt())
        }
        val scroll = ScrollView(this)
        val title = TextView(this).apply {
            text = "🎙 Robin SIM Assistant"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFBBD4F6.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        detail = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFFFD8A8.toInt())
            setPadding(0, 6, 0, 14)
        }
        page.addView(title, matchWrap())
        page.addView(status, matchWrap())
        page.addView(button("Android permissions जाँचें") { requestRuntimePermissions() }, matchWrap())
        page.addView(button("Default Phone app अनुमति दें") { requestDialerRole() }, matchWrap())
        page.addView(button("Auto-answer चालू करें") {
            if (!hasPhoneRole()) {
                Toast.makeText(this, "पहले Default Phone app role दें", Toast.LENGTH_LONG).show()
                requestDialerRole()
            } else if (!hasRequiredPermissions()) {
                requestRuntimePermissions()
                Toast.makeText(this, "ज़रूरी permissions दें, फिर दोबारा चालू करें", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit().putBoolean("auto_answer", true).apply()
                updateStatus()
                Toast.makeText(this, "Auto-answer चालू — incoming calls पर प्रयास होगा", Toast.LENGTH_LONG).show()
            }
        }, matchWrap())
        page.addView(button("⏹ अभी बंद करें") {
            stopAssistant("In-app stop button")
        }, matchWrap())
        page.addView(button("App settings खोलें") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            })
        }, matchWrap())
        page.addView(detail, matchWrap())
        val warning = TextView(this).apply {
            text = "\nज़रूरी सीमा: यह app incoming SIM call को detect/answer करने का prototype है। सामान्य Android app cellular call की दूसरी तरफ़ की आवाज़ reliably सुनकर उसी call में AI voice भेज नहीं सकती। AI से वास्तविक बातचीत के लिए supported call-forwarding/telephony provider backend चाहिए।"
            textSize = 13f
            setTextColor(0xFFFFD8A8.toInt())
        }
        page.addView(warning, matchWrap())
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun requestRuntimePermissions() {
        val wanted = mutableListOf(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 26) wanted.add(Manifest.permission.ANSWER_PHONE_CALLS)
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = wanted.distinct().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), permissionRequestCode)
        else {
            Toast.makeText(this, "Runtime permissions पहले से granted हैं", Toast.LENGTH_SHORT).show()
            updateStatus()
        }
    }

    private fun hasRequiredPermissions(): Boolean {
        val phoneState = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        val answer = if (Build.VERSION.SDK_INT >= 26) {
            checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
        } else true
        return phoneState && answer
    }

    private fun hasPhoneRole(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_DIALER)
    }

    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val manager = getSystemService(RoleManager::class.java)
            if (manager.isRoleAvailable(RoleManager.ROLE_DIALER) && !manager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                startActivityForResult(manager.createRequestRoleIntent(RoleManager.ROLE_DIALER), 501)
            } else {
                Toast.makeText(this, if (manager.isRoleHeld(RoleManager.ROLE_DIALER)) "Default Phone role पहले से granted" else "इस device पर role उपलब्ध नहीं", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "Default dialer role request के लिए Android 10+ चाहिए", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopAssistant(reason: String) {
        prefs.edit().putBoolean("auto_answer", false).apply()
        updateStatus()
        Toast.makeText(this, "Robin बंद: $reason", Toast.LENGTH_LONG).show()
    }

    // Volume Down is a convenience stop only while this Activity is foreground.
    // Android does not guarantee delivery of hardware keys while app is backgrounded.
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && prefs.getBoolean("auto_answer", false)) {
            stopAssistant("Volume Down")
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        val enabled = prefs.getBoolean("auto_answer", false)
        val role = hasPhoneRole()
        val permissions = hasRequiredPermissions()
        status.text = "Auto-answer: ${if (enabled) "ON" else "OFF"}\nDefault Phone role: ${if (role) "GRANTED" else "NOT GRANTED"}\nPhone permissions: ${if (permissions) "GRANTED" else "MISSING"}"
        detail.text = "Last phone state: ${prefs.getString("last_phone_state", "Unknown")}\nLast event: ${prefs.getString("last_phone_event", "No event")}"
    }

    @Deprecated("Deprecated Android role result callback retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 501) updateStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }
}
