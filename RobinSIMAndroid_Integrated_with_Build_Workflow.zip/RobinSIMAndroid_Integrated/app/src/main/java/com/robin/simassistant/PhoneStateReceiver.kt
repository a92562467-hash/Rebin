package com.robin.simassistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log

/**
 * PHONE_STATE broadcast is for status/logging only; it cannot answer a call.
 * InCallService is responsible for call control when the app has the required role.
 */
class PhoneStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: "UNKNOWN"
        val prefs = context.getSharedPreferences("robin_settings", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("last_phone_state", state)
            .putString("last_phone_event", System.currentTimeMillis().toString())
            .apply()
        Log.i("RobinSIM", "Phone state broadcast: $state")
    }
}
