# Robin SIM Assistant — native Android integration prototype

This project adds native Android `PhoneStateReceiver` + `InCallService` to the Robin app and places the earlier HTML control panel in `app/src/main/assets/Robin_SIM_Assistant.html`.

## What was added
- Runtime request for `READ_PHONE_STATE`, `ANSWER_PHONE_CALLS` and Android 13+ notifications permission.
- Default Phone/Dialer role request.
- `PhoneStateReceiver` for phone-state status logging only.
- `RobinInCallService` that attempts to answer a ringing call after 700 ms only when:
  1. the user enabled Auto-answer, and
  2. Android granted this app the default dialer role.
- In-app **Stop** button.
- Volume Down as a convenience stop while `MainActivity` is foreground only. Android does not reliably send volume-key events to a background app.
- The HTML settings panel is included as an asset; it does not itself control the native Telecom service.

## Build
1. Open this folder in Android Studio (recent version with Android SDK 36 installed).
2. Allow Gradle sync.
3. Build > Build APK(s).
4. Install on a test phone. Grant permissions and explicitly request the Default Phone app role.
5. Test using a spare phone first. Enable auto-answer only when you intend to answer incoming calls automatically.

## Important limitations
- This is not tested on a real SIM call in this environment; OEM/Android policy can differ.
- Android may reject the default-dialer role if the app does not satisfy the complete dialer UI requirements for that device. If so, use the system phone app and a supported telephony provider.
- The native code can request answer; it does not make the AI hear cellular downlink audio or inject generated speech into the cellular uplink.
- For full AI conversation, use call forwarding/programmable telephony provider + cloud backend. Keep API keys on the server, never inside the APK.
- Do not use for recording or handling calls without informing callers and complying with local law.


## Build APK without installing Android Studio locally (GitHub Actions)
This ZIP includes `.github/workflows/build-apk.yml`. Upload the extracted project to a GitHub repository, then open **Actions → Build Robin SIM Assistant APK → Run workflow**. After it finishes, open that workflow run and download the `RobinSIMAssistant-debug-apk` artifact. The first cloud build may reveal SDK/plugin issues; this workflow has not been executed in this environment.
